package model;

import control.EstimatorInterface;

public class DummyLocalizer implements EstimatorInterface {
		
	private int rows, cols, head;
	private double [][] T;

	public DummyLocalizer( int rows, int cols, int head) {

        this.rows = rows;
        this.cols = cols;
        this.head = head;
        T = new double[rows*cols*4][rows*cols*4];
        setCorners();
        setEdges();
        setInner();
        for(int i = 0;i<rows*cols*4;i++){
            for(int j = 0;j<rows*cols*4;j++){
                System.out.print(" " +T[i][j]);
            }
            System.out.println();
        }
	}

	private void setCorners(){
        //S[0][0] ////Going east, and south
        T[0][head+1] = 0.5; //00N
        T[0][2+rows*cols] = 0.5;
        T[1][head+1] = 0.7; //OOE
        T[1][2+rows*cols] = 0.3;
        T[2][head+1] = 0.3; //00S
        T[2][2+rows*cols] = 0.7;
        T[3][head+1] = 0.5; //00W
        T[3][2+rows*cols] = 0.5;
        //S[0][rows-1] //// going west, and south
        T[cols*(cols-1)][cols*(cols-1)-head+3] = 0.5; //0CN
        T[cols*(cols-1)][cols*(cols-1)+cols*rows+2] = 0.5;
        T[cols*(cols-1)+1][cols*(cols-1)-head+3] = 0.5; //OCE
        T[cols*(cols-1)+1][cols*(cols-1)+cols*rows+2] = 0.5;
        T[cols*(cols-1)+2][cols*(cols-1)-head+3] = 0.3; //0CS
        T[cols*(cols-1)+2][cols*(cols-1)+cols*rows+2] = 0.7;
        T[cols*(cols-1)+3][cols*(cols-1)-head+3] = 0.7; //0CW
        T[cols*(cols-1)+3][cols*(cols-1)+cols*rows+2] = 0.3;

        //S[rows-1][0] ///going north, and east
        T[(rows-1)*rows*cols][(rows-2)*rows*cols] = 0.7; //0CN
        T[(rows-1)*rows*cols][(rows-1)*rows*cols+head+1] = 0.3;
        T[(rows-1)*rows*cols+1][(rows-2)*rows*cols] = 0.3; //OCE
        T[(rows-1)*rows*cols+1][(rows-1)*rows*cols+head+1] = 0.7;
        T[(rows-1)*rows*cols+2][(rows-2)*rows*cols] = 0.5; //0CS
        T[(rows-1)*rows*cols+2][(rows-1)*rows*cols+head+1] = 0.5;
        T[(rows-1)*rows*cols+3][(rows-2)*rows*cols] = 0.5; //0CW
        T[(rows-1)*rows*cols+3][(rows-1)*rows*cols+head+1] = 0.5;

        //S[rows-1][0] //going north, and west

        T[cols*rows*(head-1)+cols*(cols-1)][cols*rows*(head-1)+cols*(cols-1)-cols*rows] = 0.7; //0CN
        T[cols*rows*(head-1)+cols*(cols-1)][cols*rows*(head-1)+cols*(cols-1)-head+3] = 0.3;
        T[cols*rows*(head-1)+cols*(cols-1)+1][cols*rows*(head-1)+cols*(cols-1)-cols*rows] = 0.5; //OCE
        T[cols*rows*(head-1)+cols*(cols-1)+1][cols*rows*(head-1)+cols*(cols-1)-head+3] = 0.5;
        T[cols*rows*(head-1)+cols*(cols-1)+2][cols*rows*(head-1)+cols*(cols-1)-cols*rows] = 0.5; //0CS
        T[cols*rows*(head-1)+cols*(cols-1)+2][cols*rows*(head-1)+cols*(cols-1)-head+3] = 0.5;
        T[cols*rows*(head-1)+cols*(cols-1)+3][cols*rows*(head-1)+cols*(cols-1)-cols*rows] = 0.3; //0CW
        T[cols*rows*(head-1)+cols*(cols-1)+3][cols*rows*(head-1)+cols*(cols-1)-head+3] = 0.7;
    }
    private void setEdges(){
	    for(int i = 1;i<cols-1;i++){ //north edge
	        for(int k = 0;k<head;k++) {
                if ((i * cols + k) % 4 == 0) { //N
                    T[i * cols + k][(i-1) * cols + 3] = 0.333;
                    T[i * cols + k][(i+1) * cols + 1] = 0.333;
                    T[i * cols + k][(i) * cols + 2 + rows*cols] = 0.333;
                } else if ((i * cols + k) % 4 == 1) { //e
                    T[i * cols + k][(i-1) * cols + 3] = 0.15;
                    T[i * cols + k][(i+1) * cols + 1] = 0.7;
                    T[i * cols + k][(i) * cols + 2 + rows*cols] = 0.15;
                }else if ((i * cols + k) % 4 == 2) { //s
                    T[i * cols + k][(i-1) * cols + 3] = 0.15;
                    T[i * cols + k][(i+1) * cols + 1] = 0.15;
                    T[i * cols + k][(i) * cols + 2 + rows*cols] = 0.7;
                }else if ((i * cols + k) % 4 == 3) { //w
                    T[i * cols + k][(i-1) * cols + 3] = 0.7;
                    T[i * cols + k][(i+1) * cols + 1] = 0.15;
                    T[i * cols + k][(i) * cols + 2 + rows*cols] = 0.15;
                }
            }
        }
        for(int i = 1;i<cols-1;i++){ //east edge
            for(int k = 0;k<head;k++) {
                if ((i * rows*cols + (cols-1)*cols+ k) % 4 == 0) { //N
                    T[i * rows*cols + (cols-1)*cols+k][(i-1) * rows*cols + (cols-1)*cols + 3] = 0.15;//w
                    T[i * rows*cols + (cols-1)*cols+k][(i) * rows*cols + (cols-1)*cols - rows*cols] = 0.7;//n
                    T[i * rows*cols + (cols-1)*cols+k][(i) * rows*cols + (cols-1)*cols + 2 + rows*cols] = 0.15;//s
                } else if ((i * rows*cols + (cols-1)*cols+k) % 4 == 1) { //e
                    T[i * rows*cols + (cols-1)*cols+k][(i-1) * rows*cols + (cols-1)*cols + 3] = 0.333;
                    T[i * rows*cols + (cols-1)*cols+k][(i) * rows*cols + (cols-1)*cols - rows*cols] = 0.333;
                    T[i * rows*cols + (cols-1)*cols+k][(i) * rows*cols + (cols-1)*cols + 2 + rows*cols] = 0.333;
                }else if ((i * rows*cols + (cols-1)*cols+k) % 4 == 2) { //s
                    T[i * rows*cols + (cols-1)*cols+k][(i-1) * rows*cols + (cols-1)*cols + 3] = 0.15;
                    T[i * rows*cols + (cols-1)*cols+k][(i) * rows*cols + (cols-1)*cols - rows*cols] = 0.15;
                    T[i * rows*cols + (cols-1)*cols+k][(i) * rows*cols + (cols-1)*cols + 2 + rows*cols] = 0.7;
                }else if ((i * rows*cols + (cols-1)*cols+k) % 4 == 3) { //w
                    T[i * rows*cols + (cols-1)*cols+k][(i-1) * rows*cols + (cols-1)*cols + 3] = 0.7;
                    T[i * rows*cols + (cols-1)*cols+k][(i) * rows*cols + (cols-1)*cols - rows*cols] = 0.15;
                    T[i * rows*cols + (cols-1)*cols+k][(i) * rows*cols + (cols-1)*cols + 2 + rows*cols] = 0.15;
                }
            }
        }
        for(int i = 1;i<cols-1;i++){ //south edge
            for(int k = 0;k<head;k++) {
                if ((rows*cols*(rows-1) + i * cols + k) % 4 == 0) { //N
                    T[rows*cols*(rows-1) + i * cols + k][rows*cols*(rows-1) + (i-1) * cols + 3] = 0.15;
                    T[rows*cols*(rows-1) + i * cols + k][rows*cols*(rows-1) + (i+1) * cols + 1] = 0.15;
                    T[rows*cols*(rows-1) + i * cols + k][rows*cols*(rows-1) + (i) * cols - rows*cols] = 0.7;
                } else if ((rows*cols*(rows-1) + i * cols + k) % 4 == 1) { //e
                    T[rows*cols*(rows-1) + i * cols + k][rows*cols*(rows-1) + (i-1) * cols + 3] = 0.15;
                    T[rows*cols*(rows-1) + i * cols + k][rows*cols*(rows-1) + (i+1) * cols + 1] = 0.7;
                    T[rows*cols*(rows-1) + i * cols + k][rows*cols*(rows-1) + (i) * cols - rows*cols] = 0.15;
                }else if ((rows*cols*(rows-1) + i * cols + k) % 4 == 2) { //s
                    T[rows*cols*(rows-1) + i * cols + k][rows*cols*(rows-1) + (i-1) * cols + 3] = 0.333;
                    T[rows*cols*(rows-1) + i * cols + k][rows*cols*(rows-1) + (i+1) * cols + 1] = 0.333;
                    T[rows*cols*(rows-1) + i * cols + k][rows*cols*(rows-1) + (i) * cols - rows*cols] = 0.333;
                }else if ((rows*cols*(rows-1) + i * cols + k) % 4 == 3) { //w
                    T[rows*cols*(rows-1) + i * cols + k][rows*cols*(rows-1) + (i-1) * cols + 3] = 0.7;
                    T[rows*cols*(rows-1) + i * cols + k][rows*cols*(rows-1) + (i+1) * cols + 1] = 0.15;
                    T[rows*cols*(rows-1) + i * cols + k][rows*cols*(rows-1) + (i) * cols - rows*cols] = 0.15;
                }
            }
        }
        for(int i = 1;i<cols-1;i++){ //west edge
            for(int k = 0;k<head;k++) {
                if ((i * rows*cols + k) % 4 == 0) { //N
                    T[i * rows*cols+k][(i) * rows*cols + cols + 1] = 0.15;//e
                    T[i * rows*cols+k][(i) * rows*cols - rows*cols] = 0.7;//n
                    T[i * rows*cols+k][(i) * rows*cols + 2 + rows*cols] = 0.15;//s
                } else if ((i * rows*cols+k) % 4 == 1) { //e
                    T[i * rows*cols+k][(i) * rows*cols +cols + 1] = 0.7;
                    T[i * rows*cols+k][(i) * rows*cols +cols - rows*cols] = 0.15;
                    T[i * rows*cols+k][(i) * rows*cols  + 2 + rows*cols] = 0.15;
                }else if ((i * rows*cols+k) % 4 == 2) { //s
                    T[i * rows*cols+k][(i) * rows*cols +cols + 1] = 0.15;
                    T[i * rows*cols+k][(i) * rows*cols- rows*cols] = 0.15;
                    T[i * rows*cols+k][(i) * rows*cols+ 2 + rows*cols] = 0.7;
                }else if ((i * rows*cols+k) % 4 == 3) { //w
                    T[i * rows*cols+k][(i) * rows*cols +cols+ 1] = 0.333;
                    T[i * rows*cols+k][(i) * rows*cols- rows*cols] = 0.333;
                    T[i * rows*cols+k][(i) * rows*cols + 2 + rows*cols] = 0.333;
                }
            }
        }

    }
    private void setInner(){
        for (int i = 1;i<rows-1;i++){
            for (int j = 1;j<cols-1;j++){
                for(int k = 0;k<head;k++){
                    if((i*rows*cols+j*cols+k)%4==0) { //N
                        T[i * rows * cols + j * cols+k][(i - 1) * rows * cols + (j + 1) * cols] = 0.7;
                        T[i * rows * cols + j * cols+k][i * rows * cols + (j - 1) * cols+3] = 0.1;
                        T[i * rows * cols + j * cols+k][(i + 1) * rows * cols + j * cols+2] = 0.1;
                        T[i * rows * cols + j * cols+k][i * rows * cols + (j + 1) * cols+1] = 0.1;
                    } else if((i*rows*cols+j*cols+k)%4==1) { //E
                        T[i * rows * cols + j * cols+k][(i - 1) * rows * cols + (j + 1) * cols] = 0.1;
                        T[i * rows * cols + j * cols+k][i * rows * cols + (j - 1) * cols+3] = 0.1;
                        T[i * rows * cols + j * cols+k][(i + 1) * rows * cols + j * cols+2] = 0.1;
                        T[i * rows * cols + j * cols+k][i * rows * cols + (j + 1) * cols+1] = 0.7;
                    }else if((i*rows*cols+j*cols+k)%4==2) { //S
                        T[i * rows * cols + j * cols+k][(i - 1) * rows * cols + (j + 1) * cols] = 0.1;
                        T[i * rows * cols + j * cols+k][i * rows * cols + (j - 1) * cols+3] = 0.1;
                        T[i * rows * cols + j * cols+k][(i + 1) * rows * cols + j * cols+2] = 0.7;
                        T[i * rows * cols + j * cols+k][i * rows * cols + (j + 1) * cols+1] = 0.1;
                    }else if((i*rows*cols+j*cols+k)%4==3) { //W
                        T[i * rows * cols + j * cols + k][(i - 1) * rows * cols + (j + 1) * cols] = 0.1;
                        T[i * rows * cols + j * cols + k][i * rows * cols + (j - 1) * cols + 3] = 0.7;
                        T[i * rows * cols + j * cols + k][(i + 1) * rows * cols + j * cols + 2] = 0.1;
                        T[i * rows * cols + j * cols + k][i * rows * cols + (j + 1) * cols + 1] = 0.1;
                    }
                }
            }
        }
    }
	public int getNumRows() {
		return rows;
	}
	
	public int getNumCols() {
		return cols;
	}
	
	public int getNumHead() {
		return head;
	}
	
	public double getTProb( int x, int y, int h, int nX, int nY, int nH) {

		return 0.0;
	}

	public double getOrXY( int rX, int rY, int x, int y, int h) {

		return 0.1;
	}


	public int[] getCurrentTrueState() {
		double a = Math.random();
		a = a*rows*cols;
		System.out.println((int) a + " " + a);
		int[] ret = new int[3];
		ret[0] = rows/2-1;
		ret[1] = cols/2;
		ret[2] = head;
		return ret;

	}

	public int[] getCurrentReading() {
		int[] ret = null;
		return ret;
	}


	public double getCurrentProb( int x, int y) {
		double ret = 0.0;
		return ret;
	}
	
	public void update() {

	    System.out.println("Nothing is happening, no model to go for...");
	}
	
	
}